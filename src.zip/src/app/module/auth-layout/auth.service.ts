import { Injectable } from '@angular/core';
import{ HttpClient } from '@angular/common/http';
import { login } from '../../shared/models/login.models';
import { register } from '../../shared/models/register.models';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private httpobj:HttpClient) { }
  login(params) {
    return this.httpobj.post<login[]>('https://11fa63d0-950e-40ba-95f7-a5d38f6277b7.mock.pstmn.io/auth/login',{params});
  }
  register(params) {
    return this.httpobj.post<register[]>('https://11fa63d0-950e-40ba-95f7-a5d38f6277b7.mock.pstmn.io/auth/register',{params});
  }
}
