import { UserService } from '../shared/services';

export function appInitializer(userService: UserService) {
    return () => new Promise(resolve => {
        // attempt to refresh token on app start up to auto authenticate
        userService.refreshToken()
            .subscribe()
            .add(resolve);
    });
}