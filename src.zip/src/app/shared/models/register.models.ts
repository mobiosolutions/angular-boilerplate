
export class register
{
  'firstname':string;
  'lastname':string;
  'mobile':number;
  'files':string;
  'email':string;
  'password':string;
}
