import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  console.log("this.currentUser",this.currentUser);
  
   }
   public get currentUserValue(): User {
    return this.currentUserSubject.value;
   }
   login(username: string, password: string) {
    return this.http.post<any>(`/users/authenticate`, { username, password })
        .pipe(map(user => {
            // login successful if there's a jwt token in the response
            if (user && user.token) {
              console.log("user.token",user.token);
              
                // store user details and jwt token in local storage to keep user logged in between page refreshes
                localStorage.setItem('currentUser', JSON.stringify(user));
                this.currentUserSubject.next(user);
            }
  
            return user;
        }));
  }
  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }  
getAll() {
    return this.http.get<User[]>(`/users`);
}

register(user: User) {
    return this.http.post(`/users/register`, user);
}
 
forgotPassword(email: string) {
  return this.http.post(`/users/forgot-password`, { email });
}
resetPassword(token: string, password: string,) {
  return this.http.post(`/users/reset-password`, { token, password});
}
validateResetToken(token: string) {
  return this.http.post(`/users/validate-reset-token`, { token });
}
refreshToken() {
  return this.http.post<any>(`/users/refresh-token`, {}, { withCredentials: true })
      .pipe(map((user) => {
          this.currentUserSubject.next(user);
          this.startRefreshTokenTimer();
          return user;
      }));
}

delete(id: number) {
    return this.http.delete(`/users/${id}`);
}
//hepler function
private refreshTokenTimeout;

    private startRefreshTokenTimer() {
        // parse json object from base64 encoded jwt token
        const jwtToken = JSON.parse(atob(this.currentUserValue.token.split('.')[1]));

        // set a timeout to refresh the token a minute before it expires
        const expires = new Date(jwtToken.exp * 1000);
        const timeout = expires.getTime() - Date.now() - (60 * 1000);
        this.refreshTokenTimeout = setTimeout(() => this.refreshToken().subscribe(), timeout);
    }

    private stopRefreshTokenTimer() {
        clearTimeout(this.refreshTokenTimeout);
    }
}
