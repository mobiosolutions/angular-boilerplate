import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder} from '@angular/forms';
import { Router,ActivatedRoute} from '@angular/router';
import { AuthService} from 'src/app/module/auth-layout/auth.service';
import { EmailValidator,passValidator } from '../../../shared/validation';
import { login } from '../../../shared/models/login.models';
import { first } from 'rxjs/operators';
import { AlertService, AuthenticationService, UserService } from '../../../shared/services';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit{
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  constructor(
    private formBuilder: FormBuilder,
    private authService:AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private alertService: AlertService,
    private userService:UserService) {
      // redirect  if already logged in
      if (this.userService.currentUserValue) { 
        this.router.navigate(['dashboard']);
    }
    }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      "username": new FormControl(null, [EmailValidator,Validators.required]),
      "password": new FormControl(null,[passValidator,Validators.required])
    });
        
    
  }
   // convenience getter for easy access to form fields
   get f() { return this.loginForm.controls; }
  Login()
  {
        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }
  console.log(this.f.username.value, this.f.password.value);
  this.userService.login(this.f.username.value, this.f.password.value)
            .pipe(first())
            .subscribe(
                data => {
                    this.router.navigate(['dashboard']);
                },
                error => {
                    this.alertService.error(error);
                });
    }
  

}
