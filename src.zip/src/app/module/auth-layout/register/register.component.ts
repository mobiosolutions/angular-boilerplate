import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder} from '@angular/forms';
import { Router } from '@angular/router';
import {AuthService } from 'src/app/module/auth-layout/auth.service';
import { EmailValidator,passValidator,PhoneValidator,NameValidator} from '../../../shared/validation';
import { register } from '../../../shared/models/register.models';
import { first } from 'rxjs/operators';
import { AlertService, UserService, AuthenticationService } from '../../../shared/services';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  url:any;
  registraionForm: FormGroup;
  loading = false;
  submitted = false;
  constructor(
    private formBuilder: FormBuilder,
    private authService:AuthService,
    private authenticationService: AuthenticationService,
    private router:Router,
    private alertService: AlertService,
    private userService:UserService) {
       // redirect to home if already logged in
       if (this.userService.currentUserValue) { 
        this.router.navigate(['/']);
    }
     }

  ngOnInit() {
    this.registraionForm = this.formBuilder.group({
      firstname:['',[NameValidator,Validators.required]],
      lastname:['',[NameValidator,Validators.required]],
      mobile:['',[PhoneValidator,Validators.required]],
      username:['',[EmailValidator,Validators.required]],
      password: ['',[passValidator,Validators.required]],
    });
    
  }
  // onSelectFile(event) {
  //   if (event.target.files && event.target.files[0]) {
  //     var reader = new FileReader();
  //     reader.readAsDataURL(event.target.files[0]); // read file as data url
  //     reader.onload = (event) => { // called once readAsDataURL is completed
  //       this.url = event.target.result;
  //     }
  //   }
  // }
  // public delete(){
  //   this.url = null;
  // }
  // convenience getter for easy access to form fields
  get f() { return this.registraionForm.controls; }

  createAccount()
  {
    // stop here if form is invalid
    if (this.registraionForm.invalid) {
      return;
  }
  this.userService.register(this.registraionForm.value).subscribe(
                data => {
                    this.alertService.success('Registration successful', true);
                    this.router.navigate(['/login']);
                },
                error => {
                  console.log(error);
                     this.alertService.error(error);
                });
    }


}
