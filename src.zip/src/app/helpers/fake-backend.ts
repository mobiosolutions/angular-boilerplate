import { Injectable } from '@angular/core';
import { HttpRequest, HttpResponse, HttpHandler, HttpEvent, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay, mergeMap, materialize, dematerialize } from 'rxjs/operators';

// array in local storage for registered users
let users = JSON.parse(localStorage.getItem('users')) || [];

@Injectable()
export class FakeBackendInterceptor implements HttpInterceptor {
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const { url, method, headers, body } = request;

        // wrap in delayed observable to simulate server api call
        return of(null)
            .pipe(mergeMap(handleRoute))
            .pipe(materialize()) // call materialize and dematerialize to ensure delay even if an error is thrown (https://github.com/Reactive-Extensions/RxJS/issues/648)
            .pipe(delay(500))
            .pipe(dematerialize());

        function handleRoute() {
            switch (true) {
                case url.endsWith('/users/authenticate') && method === 'POST':
                    return authenticate();
                case url.endsWith('/users/register') && method === 'POST':
                    return register();
                    case url.endsWith('/users/refresh-token') && method === 'POST':
                        return refreshToken();
                    case url.endsWith('/users/forgot-password') && method === 'POST':
                    return forgotPassword();
                    case url.endsWith('/users/validate-reset-token') && method === 'POST':
                    return validateResetToken();
                    case url.endsWith('/users/reset-password') && method === 'POST':
                    return resetPassword();
                case url.endsWith('/users') && method === 'GET':
                    return getUsers();
                case url.match(/\/users\/\d+$/) && method === 'DELETE':
                    return deleteUser();
                default:
                    // pass through any requests not handled above
                    return next.handle(request);
            }    
        }

        // route functions

        function authenticate() {
            const { username, password } = body;
            console.log("authenticate",body);
            
            const user = users.find(x => x.username === username && x.password === password);
            if (!user) return error('Username or password is incorrect');
            return ok({
                id: user.id,
                username: user.username,
                firstName: user.firstName,
                lastName: user.lastName,
                token: 'fake-jwt-token'
            })
        }

        function register() {
            const user = body
            console.log("register",user);

            if (users.find(x => x.username === user.username)) {
                return error('Username "' + user.username + '" is already taken')
            }
            
            // user.id =  users.id ;
            // console.log("userid",user.id,users,users.length);
            
            // user.id = users.length ? Math.max(...users.map(x => x.id)) + 1 : 1;
            users.push(user);
            localStorage.setItem('users', JSON.stringify(users));

            return ok();
        }
        function forgotPassword() {
            const { email } = body;
            const user = users.find(x => x.email === email);
            
            // always return ok() response to prevent email enumeration
            if (!user) return ok();
            
            // create reset token that expires after 24 hours
            user.resetToken = new Date().getTime().toString();
            user.resetTokenExpires = new Date(Date.now() + 24*60*60*1000).toISOString();
            localStorage.setItem('users', JSON.stringify(users));

            // display password reset email in alert
            setTimeout(() => {
                const resetUrl = `${location.origin}/users/reset-password?token=${user.resetToken}`;
                this.alertService.info(`
                    <h4>Reset Password Email</h4>
                    <p>Please click the below link to reset your password, the link will be valid for 1 day:</p>
                    <p><a href="${resetUrl}">${resetUrl}</a></p>
                    <div><strong>NOTE:</strong> The fake backend displayed this "email" so you can test without an api. A real backend would send a real email.</div>
                `, { autoClose: false });
            }, 1000);

            return ok();
        }
        function validateResetToken() {
            const { token } = body;
            const user = users.find(x =>
                !!x.resetToken && x.resetToken === token &&
                new Date() < new Date(x.resetTokenExpires)
            );
            
            if (!user) return error('Invalid token');
            
            return ok();
        }
        function resetPassword() {
            const { token, password } = body;
            const user = users.find(x =>
                !!x.resetToken && x.resetToken === token &&
                new Date() < new Date(x.resetTokenExpires)
            );
            
            if (!user) return error('Invalid token');
            
            // update password and remove reset token
            user.password = password;
            user.isVerified = true;
            delete user.resetToken;
            delete user.resetTokenExpires;
            localStorage.setItem('users', JSON.stringify(users));

            return ok();
        }
        function refreshToken() {
            const refreshToken = getRefreshToken();
            
            if (!refreshToken) return unauthorized();

            const user = users.find(x => x.refreshTokens.includes(refreshToken));
            
            if (!user) return unauthorized();

            // replace old refresh token with a new one and save
            user.refreshTokens = user.refreshTokens.filter(x => x !== refreshToken);
            user.refreshTokens.push(generateRefreshToken());
            localStorage.setItem('users', JSON.stringify(users));

            return ok({
                ...basicDetails(user),
                jwtToken: this.generateJwtToken()
            });

        }

        function getUsers() {
            if (!isLoggedIn()) return unauthorized();
            return ok(users);
        }

        function deleteUser() {
            if (!isLoggedIn()) return unauthorized();

            users = users.filter(x => x.id !== idFromUrl());
            localStorage.setItem('users', JSON.stringify(users));
            return ok();
        }

        // helper functions

        function ok(body?) {
            return of(new HttpResponse({ status: 200, body }))
        }

        function error(message) {
            return throwError({ error: { message } });
        }

        function unauthorized() {
            return throwError({ status: 401, error: { message: 'Unauthorised' } });
        }

        function isLoggedIn() {
            return headers.get('Authorization') === 'Bearer fake-jwt-token';
        }

        function idFromUrl() {
            const urlParts = url.split('/');
            return parseInt(urlParts[urlParts.length - 1]);
        }
        function basicDetails(user) {
            const { id,  firstName, lastName, email,  dateCreated, isVerified } = users;
            return { id, firstName, lastName, email,  dateCreated, isVerified };
        }
    }
}
function generateJwtToken(user) {
    // create token that expires in 15 minutes
    const tokenPayload = { 
        exp: Math.round(new Date(Date.now() + 15*60*1000).getTime() / 1000),
        id: user.id
    }
    return `fake-jwt-token.${btoa(JSON.stringify(tokenPayload))}`;
}

function generateRefreshToken() {
    const token = new Date().getTime().toString();

    // add token cookie that expires in 7 days
    const expires = new Date(Date.now() + 7*24*60*60*1000).toUTCString();
    document.cookie = `fakeRefreshToken=${token}; expires=${expires}; path=/`;

    return token;
}

function getRefreshToken() {
    // get refresh token from cookie
    return (document.cookie.split(';').find(x => x.includes('fakeRefreshToken')) || '=').split('=')[1];
}

export const fakeBackendProvider = {
    // use fake backend in place of Http service for backend-less development
    provide: HTTP_INTERCEPTORS,
    useClass: FakeBackendInterceptor,
    multi: true
};